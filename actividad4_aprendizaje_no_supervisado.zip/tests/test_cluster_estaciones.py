import unittest
from pathlib import Path

from src.cluster_estaciones import cargar_datos, entrenar, calcular_silueta

DATA = Path(__file__).parents[1] / "data" / "perfiles_estaciones.csv"


class TestClusterEstaciones(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.datos = cargar_datos(DATA)
        cls.modelo, cls.resultado = entrenar(cls.datos, k=3)

    def test_dataset_sin_variable_objetivo(self):
        self.assertEqual(len(self.datos), 45)
        self.assertNotIn("demanda_alta", self.datos.columns)

    def test_asigna_un_grupo_a_cada_registro(self):
        self.assertEqual(len(self.resultado["grupo"]), 45)
        self.assertEqual(self.resultado["grupo"].nunique(), 3)

    def test_silueta_en_rango_valido(self):
        silueta = calcular_silueta(self.modelo, self.datos, self.resultado["grupo"])
        self.assertGreaterEqual(silueta, -1.0)
        self.assertLessEqual(silueta, 1.0)

    def test_columnas_faltantes(self):
        datos = self.datos.drop(columns=["clima"])
        with self.assertRaises(ValueError):
            cargar_datos(datos)


if __name__ == "__main__":
    unittest.main()
