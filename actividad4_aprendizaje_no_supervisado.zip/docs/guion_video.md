# Guion del video — máximo 10 minutos

## Distribución para máximo tres integrantes

| Tiempo | Participante | Contenido |
|---|---|---|
| 0:00–0:50 | Integrante 1 | Presentación, problema y objetivo. |
| 0:50–2:20 | Integrante 1 | Dataset, variables y diferencia entre aprendizaje supervisado y no supervisado. |
| 2:20–4:00 | Integrante 2 | Código, preprocesamiento y elección de K-Means. |
| 4:00–5:30 | Integrante 2 | Ejecución del programa y explicación de grupos y silueta. |
| 5:30–7:00 | Integrante 3 | Gráfica, promedios por grupo y limitaciones. |
| 7:00–8:30 | Integrante 3 | Pruebas automáticas. |
| 8:30–10:00 | Todos | Mapa conceptual, conclusiones y despedida. |

## Texto para presentar

“En esta actividad desarrollamos un modelo de aprendizaje no supervisado aplicado al transporte masivo. El objetivo es encontrar perfiles de operación parecidos entre diferentes observaciones de estaciones. A diferencia del aprendizaje supervisado, aquí no tenemos una columna que indique cuál debería ser el grupo correcto.”

“Utilizamos un dataset académico de 45 registros. Cada registro contiene la estación, día, hora, clima, evento, cantidad de pasajeros, ocupación, incidentes y tiempo de espera. La muestra fue construida para el ejercicio porque no contamos con datos operativos autorizados. Por esta razón, no representa información oficial ni tiempo real.”

“Primero cargamos el archivo CSV. Después separamos las variables categóricas de las numéricas. Las variables categóricas se transforman con one-hot encoding y las variables numéricas se estandarizan. Esta preparación es importante porque K-Means utiliza distancias para formar los grupos.”

“Utilizamos K-Means con tres grupos. El algoritmo comienza con centroides y asigna cada observación al centro más cercano. Luego recalcula los centroides y repite el proceso hasta estabilizar las asignaciones. El número tres es una decisión exploratoria para comparar tres perfiles de operación.”

“Ejecutamos el programa con el comando `python src/cluster_estaciones.py --datos data/perfiles_estaciones.csv --k 3`. La salida muestra el número de registros, los grupos encontrados, el coeficiente de silueta y los promedios numéricos de cada grupo.”

“El coeficiente de silueta ayuda a evaluar la separación de los grupos. Toma valores entre menos uno y uno. Un valor mayor indica que las observaciones están más cerca de su propio grupo que de los grupos vecinos. Sin embargo, esta métrica no reemplaza la interpretación del equipo ni la validación con expertos en transporte.”

“También generamos una gráfica en dos dimensiones con PCA. La gráfica permite visualizar de forma aproximada cómo se distribuyen los grupos, aunque la reducción a dos dimensiones puede perder parte de la información original.”

“Finalmente ejecutamos las pruebas automáticas. Estas verifican la carga del archivo, la asignación de un grupo a cada registro, el rango válido de la silueta y el manejo de columnas faltantes.”

## Conclusión

“Concluimos que el aprendizaje no supervisado puede ayudar a descubrir perfiles de operación cuando no existen etiquetas previamente definidas. En este caso, K-Means permite agrupar observaciones de estaciones con características parecidas. El resultado es un prototipo académico y para usarlo en una operación real se necesitarían datos oficiales, más observaciones, validación temporal y revisión por parte del operador.”
