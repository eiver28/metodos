# Descripción de los datos

## Contexto

El proyecto analiza perfiles de operación de estaciones de transporte masivo. En lugar de predecir una etiqueta ya conocida, se busca descubrir grupos de observaciones que tengan comportamientos parecidos.

Como no se dispone de una fuente operacional autorizada y completa, se elaboró una muestra académica. El archivo `data/perfiles_estaciones.csv` contiene 45 registros. Cada registro corresponde a una estación observada durante una franja horaria.

## Variables

| Columna | Tipo | Descripción |
|---|---|---|
| `estacion` | Categórica | Estación observada. |
| `dia_semana` | Categórica | Día de la observación. |
| `hora` | Categórica | Franja horaria. |
| `clima` | Categórica | Condición normal o lluvia. |
| `evento` | Categórica | Indica si se registró un evento especial. |
| `demanda_pasajeros` | Numérica | Cantidad estimada de pasajeros. |
| `ocupacion_promedio` | Numérica | Proporción estimada de ocupación entre 0 y 1. |
| `incidentes` | Numérica | Número de incidentes de la franja. |
| `tiempo_espera_min` | Numérica | Tiempo promedio de espera en minutos. |

No existe una variable objetivo. Esta es la diferencia principal frente al proyecto de aprendizaje supervisado: el algoritmo recibe características, pero no recibe grupos correctos previamente definidos.

## Preparación

Las columnas categóricas se convierten con `OneHotEncoder`. Las numéricas se estandarizan con `StandardScaler` para evitar que una variable con valores grandes domine el cálculo de distancia. Luego K-Means construye tres grupos.

## Interpretación esperada

Los grupos pueden interpretarse como perfiles operativos, por ejemplo:

- Observaciones de menor actividad y tiempos de espera bajos.
- Observaciones de actividad intermedia.
- Observaciones con mayor demanda, ocupación o espera.

Estas etiquetas son interpretaciones posteriores. K-Means solamente entrega identificadores numéricos como 0, 1 y 2.

## Fuentes y limitaciones

La fuente inmediata es el CSV del repositorio, elaborado como muestra académica. En un proyecto real se podrían utilizar datos abiertos de movilidad, registros anonimizados del operador o sensores de aforo. Habría que documentar la fecha de descarga, licencia, cobertura y tratamiento de valores faltantes.

La muestra no representa toda la operación del sistema. No incluye festivos completos, transbordos, capacidad de vehículos, tiempos de viaje ni información en tiempo real. Los grupos encontrados deben entenderse como una exploración inicial.
