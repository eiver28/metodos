# Documento de entrega — Actividad 4

**Curso:** [Nombre del curso]  
**Docente:** [Nombre del tutor]  
**Grupo:** [Número]  
**Integrantes:** [Nombres completos de máximo tres estudiantes]  
**Fecha:** [Fecha]

## Proyecto

**Agrupamiento de perfiles operativos de estaciones de transporte masivo mediante K-Means.**

El proyecto utiliza una muestra de datos académica sin etiquetas y un modelo de aprendizaje no supervisado implementado en Python. K-Means agrupa observaciones con características operativas parecidas.

## Enlaces

- **Repositorio Git/GitLab:** [Pegar enlace real]
- **Video:** [Pegar enlace real]
- **Mapa conceptual:** disponible en `docs/mapa_conceptual.md`
- **Fuente de datos:** `data/perfiles_estaciones.csv`
- **Descripción de los datos:** `docs/descripcion_datos.md`
- **Pruebas:** `docs/pruebas.md`

## Archivos incluidos

- `data/perfiles_estaciones.csv`: fuente de datos de la muestra.
- `src/cluster_estaciones.py`: código Python.
- `docs/descripcion_datos.md`: descripción de las variables y limitaciones.
- `docs/pruebas.md`: pruebas y resultados.
- `docs/mapa_conceptual.md`: mapa conceptual.
- `docs/guion_video.md`: guion del video.
- `README.md`: instrucciones de instalación y ejecución.

## Aportes

| Integrante | Aporte real | Commit o enlace |
|---|---|---|
| [Nombre 1] | [Completar] | [Completar] |
| [Nombre 2] | [Completar] | [Completar] |
| [Nombre 3] | [Completar] | [Completar] |

> Completen los campos entre corchetes, agreguen al tutor como colaborador y sustituyan los resultados pendientes por la salida real obtenida por el equipo.
