# Mapa conceptual — aprendizaje no supervisado

```mermaid
flowchart TD
    A[Problema de transporte masivo] --> B[Datos sin etiquetas]
    B --> C[Variables categóricas y numéricas]
    C --> D[Preprocesamiento]
    D --> E[One-hot encoding]
    D --> F[Estandarización]
    E --> G[K-Means]
    F --> G
    G --> H[Grupos descubiertos]
    H --> I[Perfiles operativos]
    G --> J[Evaluación]
    J --> K[Coeficiente de silueta]
    I --> L[Apoyo a decisiones de operación]
```

**Idea central:** el aprendizaje no supervisado identifica estructuras o grupos en los datos sin recibir etiquetas correctas previamente definidas. En este proyecto, K-Means agrupa observaciones de estaciones con características operativas parecidas.
