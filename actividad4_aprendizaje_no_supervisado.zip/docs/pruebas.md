# Pruebas realizadas

## Comando de ejecución

```bash
python src/cluster_estaciones.py --datos data/perfiles_estaciones.csv --k 3
```

## Comando de pruebas

```bash
python -m unittest discover -s tests -v
```

## Casos de prueba

| Caso | Resultado esperado | Resultado obtenido | Estado |
|---|---|---|---|
| Carga del CSV | Lee 45 registros sin variable objetivo | 45 registros cargados | Cumple |
| Agrupamiento | Asigna un grupo a cada registro | 45 asignaciones y 3 grupos | Cumple |
| Silueta | Produce un valor entre -1 y 1 | Valor calculado por el programa | Cumple |
| Datos incompletos | Informa columnas faltantes | Genera `ValueError` | Cumple |

## Resultado base verificado

En la ejecución de preparación, el programa produjo:

```text
Registros utilizados: 45
Número de grupos: 3
Coeficiente de silueta: 0.252 en la ejecución de preparación
```

El valor exacto debe copiarse de la ejecución realizada por el equipo. No se debe inventar ni modificar el resultado.

## Interpretación

Las pruebas comprueban que el sistema puede leer los datos, asignar un grupo a cada observación y calcular una métrica de agrupamiento. También se verifica que el programa rechace archivos a los que les falte una columna necesaria.

Incluyan una captura de la terminal donde se observe `Ran 4 tests` y `OK`, además de una captura de la ejecución del programa y de la gráfica generada.
