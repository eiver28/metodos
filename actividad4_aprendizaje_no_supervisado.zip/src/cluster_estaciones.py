"""Agrupamiento no supervisado de perfiles operativos de estaciones."""
from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CATEGORICAS = ["estacion", "dia_semana", "hora", "clima", "evento"]
NUMERICAS = ["demanda_pasajeros", "ocupacion_promedio", "incidentes", "tiempo_espera_min"]


def cargar_datos(path: str | Path | pd.DataFrame) -> pd.DataFrame:
    datos = path.copy() if isinstance(path, pd.DataFrame) else pd.read_csv(path)
    requeridas = set(CATEGORICAS + NUMERICAS)
    faltantes = requeridas.difference(datos.columns)
    if faltantes:
        raise ValueError(f"Faltan columnas requeridas: {sorted(faltantes)}")
    return datos


def construir_pipeline(k: int = 3) -> Pipeline:
    transformador = ColumnTransformer([
        ("categoricas", OneHotEncoder(handle_unknown="ignore"), CATEGORICAS),
        ("numericas", StandardScaler(), NUMERICAS),
    ])
    return Pipeline([
        ("preprocesamiento", transformador),
        ("agrupamiento", KMeans(n_clusters=k, random_state=42, n_init=20)),
    ])


def entrenar(datos: pd.DataFrame, k: int = 3) -> tuple[Pipeline, pd.DataFrame]:
    modelo = construir_pipeline(k)
    grupos = modelo.fit_predict(datos[CATEGORICAS + NUMERICAS])
    resultado = datos.copy()
    resultado["grupo"] = grupos
    return modelo, resultado


def calcular_silueta(modelo: Pipeline, datos: pd.DataFrame, grupos: pd.Series) -> float:
    matriz = modelo.named_steps["preprocesamiento"].transform(datos[CATEGORICAS + NUMERICAS])
    return float(silhouette_score(matriz, grupos))


def guardar_grafico(modelo: Pipeline, datos: pd.DataFrame, grupos: pd.Series, ruta: str) -> None:
    matriz = modelo.named_steps["preprocesamiento"].transform(datos[CATEGORICAS + NUMERICAS])
    reducido = PCA(n_components=2, random_state=42).fit_transform(matriz.toarray() if hasattr(matriz, "toarray") else matriz)
    plt.figure(figsize=(8, 5))
    for grupo in sorted(grupos.unique()):
        seleccion = grupos == grupo
        plt.scatter(reducido[seleccion, 0], reducido[seleccion, 1], label=f"Grupo {grupo}")
    plt.title("Perfiles de estaciones agrupados con K-Means")
    plt.xlabel("Componente principal 1")
    plt.ylabel("Componente principal 2")
    plt.legend()
    plt.tight_layout()
    plt.savefig(ruta, dpi=160)
    plt.close()


def ejecutar(path: str, k: int, salida: str | None, grafico: str | None) -> None:
    datos = cargar_datos(path)
    modelo, resultado = entrenar(datos, k)
    silueta = calcular_silueta(modelo, datos, resultado["grupo"])
    print(f"Registros utilizados: {len(datos)}")
    print(f"Número de grupos: {k}")
    print(f"Coeficiente de silueta: {silueta:.3f}")
    print("Cantidad de observaciones por grupo:")
    print(resultado["grupo"].value_counts().sort_index().to_string())
    print("\nPromedios numéricos por grupo:")
    print(resultado.groupby("grupo")[NUMERICAS].mean().round(2).to_string())
    if salida:
        resultado.to_csv(salida, index=False)
        print(f"Resultado guardado en: {salida}")
    if grafico:
        guardar_grafico(modelo, datos, resultado["grupo"], grafico)
        print(f"Gráfico guardado en: {grafico}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--datos", default="data/perfiles_estaciones.csv")
    parser.add_argument("--k", type=int, default=3)
    parser.add_argument("--salida", default=None)
    parser.add_argument("--grafico", default=None)
    args = parser.parse_args()
    ejecutar(args.datos, args.k, args.salida, args.grafico)
