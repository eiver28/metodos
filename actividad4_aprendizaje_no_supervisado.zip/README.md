# Actividad 4 — Métodos de aprendizaje no supervisado

## Proyecto

**Agrupamiento de perfiles operativos de estaciones de transporte masivo mediante K-Means.**

El programa busca reunir observaciones parecidas sin utilizar una columna objetivo previamente etiquetada. El resultado puede ayudar a identificar perfiles de operación, por ejemplo, franjas de baja, media o alta actividad.

> El CSV incluido es una **muestra académica construida para el ejercicio**. No representa datos oficiales ni información en tiempo real de un operador.

## Instalación

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Ejecución

```bash
python src/cluster_estaciones.py \
  --datos data/perfiles_estaciones.csv \
  --k 3 \
  --salida resultados/estaciones_agrupadas.csv \
  --grafico figures/agrupamiento.png
```

Crear antes la carpeta de resultados si no existe:

```bash
mkdir -p resultados
```

En Windows se puede ejecutar en una sola línea:

```text
python src/cluster_estaciones.py --datos data/perfiles_estaciones.csv --k 3 --salida resultados/estaciones_agrupadas.csv --grafico figures/agrupamiento.png
```

## Pruebas

```bash
python -m unittest discover -s tests -v
```

## Método utilizado

K-Means agrupa las observaciones alrededor de `k` centroides. En este proyecto se eligió `k=3` como decisión exploratoria para comparar tres perfiles de operación. Las variables categóricas se codifican con one-hot encoding y las numéricas se estandarizan. El algoritmo no recibe una etiqueta como `demanda_alta`; los grupos son descubiertos a partir de las similitudes entre registros.

En la ejecución de preparación se obtuvo un coeficiente de silueta de 0.252. Este valor debe volver a comprobarse en el computador del equipo. El coeficiente de silueta toma valores entre -1 y 1. Valores más altos indican que los registros están más cerca de su propio grupo que de los grupos vecinos. La métrica orienta la interpretación, pero no demuestra por sí sola que los grupos sean verdaderos en el sistema real.

## Estructura

```text
actividad4_aprendizaje_no_supervisado/
├── data/perfiles_estaciones.csv
├── src/cluster_estaciones.py
├── tests/test_cluster_estaciones.py
├── docs/descripcion_datos.md
├── docs/pruebas.md
├── docs/mapa_conceptual.md
├── docs/guion_video.md
├── docs/entrega.md
├── figures/
├── requirements.txt
└── README.md
```

Cada integrante debe hacer un aporte real y registrar sus cambios con su propia cuenta Git. El tutor debe agregarse como colaborador del repositorio.
